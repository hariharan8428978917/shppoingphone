-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 28, 2022 at 08:02 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.0.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `groceryshop`
--

-- --------------------------------------------------------

--
-- Table structure for table `babycare`
--

CREATE TABLE `babycare` (
  `prid` int(11) NOT NULL,
  `desc` varchar(100) NOT NULL,
  `qty` varchar(100) NOT NULL,
  `rate` int(11) NOT NULL,
  `url` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `babycare`
--

INSERT INTO `babycare` (`prid`, `desc`, `qty`, `rate`, `url`) VALUES
(1, 'HAMAM  soap', '8 x 150 g', 356, 'https://rukminim1.flixcart.com/image/280/280/kbjox3k0/soap/3/h/f/8-150-neem-tulsi-aloe-vera-soap-hamam-original-imafsv33zp3b3vct.jpeg?q=70'),
(2, 'Pears Pure ', '3 x 125 g', 176, 'https://rukminim1.flixcart.com/image/280/280/kq5iykw0/soap/8/n/j/pure-gentle-bathing-bar-pears-original-imag48gcurzgpbmg.jpeg?q=70'),
(3, 'colgate ', '3 x 200g ', 178, 'https://rukminim1.flixcart.com/image/280/280/kpu3frk0/toothpaste/j/b/i/1-strong-teeth-toothpaste-india-s-no-1-toothpaste-2x-stronger-original-imag3z3zehxtmvjg.jpeg?q=70'),
(4, 'Closeup Ever Fresh', 'pack', 45, 'https://rukminim1.flixcart.com/image/280/280/kddf6a80/toothpaste/f/g/y/150-ever-fresh-closeup-original-imafuahye6azzn8g.jpeg?q=70'),
(5, 'HIMALAYA kajal cream', 'Black', 110, 'https://rukminim1.flixcart.com/image/280/280/kklhbbk0/kajal/y/d/a/kajal-himalaya-original-imafzwzhbfvgap9d.jpeg?q=70'),
(6, 'VLCC New Diamond Facial Kit', '60 g', 169, 'https://rukminim1.flixcart.com/image/280/280/jxc5a4w0/facial-kit/h/s/j/50-new-diamond-facial-kit-for-skin-polishing-and-purification-original-imafhsy9mfbsp9se.jpeg?q=70'),
(7, 'LakeMay Iconic Kajal', '60 g', 98, 'https://rukminim1.flixcart.com/image/280/280/kh80vww0/foundation/t/z/w/30-9-to-5-complexion-care-face-cream-bronze-lakme-original-imafxahkza3z5nvz.jpeg?q=70'),
(8, 'Vaseline Intensive Care Deep', '400 ml', 72, 'https://rukminim1.flixcart.com/image/280/280/knt7zbk0/moisturizer-cream/w/6/b/intensive-care-deep-restore-lotion-lotion-vaseline-original-imag2evdgdzzwy5f.jpeg?q=70');

-- --------------------------------------------------------

--
-- Table structure for table `food`
--

CREATE TABLE `food` (
  `prid` int(11) NOT NULL,
  `desc` varchar(100) NOT NULL,
  `qty` varchar(20) NOT NULL,
  `rate` int(11) NOT NULL,
  `url` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `food`
--

INSERT INTO `food` (`prid`, `desc`, `qty`, `rate`, `url`) VALUES
(1, ' Corn Flaskes ', '1 kg', 199, 'https://rukminim1.flixcart.com/image/280/280/koad9jk0/cereal-flake/9/h/k/corn-flakes-pouch-kwality-original-imag2rsyp2gzwys5.jpeg?q=70'),
(2, 'Manna Oats', '1 kg', 194, 'https://rukminim1.flixcart.com/image/280/280/kk1h5e80/cereal-flake/m/t/r/3-oats-gluten-free-steel-cut-rolled-oats-high-in-fibre-protein-original-imafzhcbgxgxfhzf.jpeg?q=70'),
(3, 'Fruits & Nuts', '500 g', 405, 'https://rukminim1.flixcart.com/image/280/280/ktrk13k0/cereal-flake/j/8/v/500-muesli-plus-box-1-yoga-bar-original-imag7fkpgaz9yz2j.jpeg?q=70'),
(4, 'Kissan  Mixed jam', '1kg', 209, 'https://rukminim1.flixcart.com/image/280/280/kdyus280/jam-spread/p/3/v/1-mixed-fruit-jam-plastic-bottle-mixed-fruit-jam-kissan-original-imafurfxpzyymx9y.jpeg?q=70'),
(5, 'Dabur Honey', '1kg', 360, 'https://rukminim1.flixcart.com/image/280/280/ku79vgw0/honey/x/c/e/honey-dabur-original-imag7dcqagtckha2.jpeg?q=70'),
(6, ' Mango Pickle', '500 g', 74, 'https://rukminim1.flixcart.com/image/280/280/kh5607k0/pickle-murabba/e/c/p/500-na-plastic-bottle-pickle-umadi-original-imafx7szk5r5unze.jpeg?q=70'),
(7, ' pizzea sauce', '325 g', 76, 'https://rukminim1.flixcart.com/image/280/280/j3q6snk0/sauce-ketchup/f/c/u/325-italian-pastapizza-sauce-plastic-bottle-pasta-fun-foods-original-imaeuqkaqm4jbuuh.jpeg?q=70'),
(8, 'Baking Soda', '100g', 17, 'https://rukminim1.flixcart.com/image/280/280/k5cs87k0/baking-ingredient/u/w/h/100-baking-soda-baking-soda-kwality-original-imafz2c3u3mgfqmk.jpeg?q=70');

-- --------------------------------------------------------

--
-- Table structure for table `house`
--

CREATE TABLE `house` (
  `prid` int(11) NOT NULL,
  `desc` varchar(100) NOT NULL,
  `qty` varchar(20) NOT NULL,
  `rate` int(11) NOT NULL,
  `url` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `house`
--

INSERT INTO `house` (`prid`, `desc`, `qty`, `rate`, `url`) VALUES
(1, 'Surf Excel Quick Wash', '2 kg', 391, 'https://rukminim1.flixcart.com/image/280/280/j9eirgw0/laundry-detergent/d/g/w/2-quick-wash-detergent-powder-surf-excel-original-imaez7gqqfpykeym.jpeg?q=70'),
(2, 'Surf excel detergent cake', '1 x 84', 9, 'https://rukminim1.flixcart.com/image/280/280/jg6v24w0/washing-bar/m/g/f/na-100-surf-excel-original-imaf4hp8k57gq9k3.jpeg?q=70'),
(3, 'comfort after wash', '1L', 300, 'https://rukminim1.flixcart.com/image/280/280/kpr8k280/fabric-softener/3/m/j/after-wash-morning-fresh-fabric-conditioner-comfort-original-imag3x9gg5edbkeg.jpeg?q=70'),
(4, 'Ariel  Liquied', '2L', 380, 'https://rukminim1.flixcart.com/image/280/280/kv8fbm80/liquid-detergent/e/z/w/-original-imag86kync6eheu6.jpeg?q=70'),
(5, ' lavender dhoop', 'pack', 11, 'https://rukminim1.flixcart.com/image/280/280/ktszgy80/dhoop-cone/f/r/u/na-flipkart-supermart-original-imag72csga3epfaq.jpeg?q=70'),
(6, 'Lamp oil', '1L', 298, 'https://rukminim1.flixcart.com/image/280/280/jn6ck280/havan-items/x/f/d/lamp-oil-1-ltr-deepa-jyoyhi-original-imaf9wsu2fedbwr2.jpeg?q=70'),
(7, 'Shoe Palisher', 'Tan', 78, 'https://rukminim1.flixcart.com/image/280/280/kqse07k0/shoe-polish-cream/y/m/k/nourishes-liquid-polish-cherry-blossom-original-imag4q2cyyrh64kg.jpeg?q=70'),
(8, 'Home Essentials', '3L', 102, 'https://rukminim1.flixcart.com/image/280/280/kg2l47k0/all-purpose-cleaner/u/q/h/toilet-cleaner-1l-phenyl-1l-dishwash-liquid-750-ml-toilet-original-imafwe36yqyadnvc.jpeg?q=70'),
(9, 'Sink Brush', '1 unit', 85, 'https://rukminim1.flixcart.com/image/280/280/kbpeoi80/broom-brush/d/j/e/132801-gala-original-imafszr293fgwhth.jpeg?q=70');

-- --------------------------------------------------------

--
-- Table structure for table `kitchen`
--

CREATE TABLE `kitchen` (
  `prid` int(11) NOT NULL,
  `desc` varchar(100) NOT NULL,
  `rate` int(11) NOT NULL,
  `qty` varchar(30) NOT NULL,
  `url` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kitchen`
--

INSERT INTO `kitchen` (`prid`, `desc`, `rate`, `qty`, `url`) VALUES
(1, 'Water Bottle', 65, 'pack', 'https://rukminim1.flixcart.com/image/280/280/k2krekw0/bottle/x/w/9/1000-botmosaicp1pnk-botmosaicp1pnk-flipkart-smartbuy-original-imafhwyysh7czey9.jpeg?q=70'),
(2, 'MASTER COOK', 74, 'clear', 'https://rukminim1.flixcart.com/image/280/280/k62i5jk0/container/x/w/k/pp-206-container-clear-with-blue-lids-mastercook-original-imafzhbnpg2v9n6t.jpeg?q=70'),
(3, '3L WATER can', 58, '94', 'https://rukminim1.flixcart.com/image/280/280/ken59jk0/jug/7/v/m/new-topaz-water-jug-with-inner-carton-2000ml-blue-princeware-original-imafv9uttfztzy6h.jpeg?q=70'),
(4, 'PRINCEWARE', 94, 'pack', 'https://rukminim1.flixcart.com/image/280/280/ken59jk0/container/u/a/q/store-fresh-square-packing-contr-3-pcs-set-1125ml-each-total-original-imafv9utgyyezssp.jpeg?q=70'),
(5, 'MASTER COK', 134, 'pack', 'https://rukminim1.flixcart.com/image/280/280/k65d18w0/container/f/e/f/combo-436-3pcs-set-211-212-213-blue-mastercook-original-imafzzky26ax4gys.jpeg?q=70'),
(6, 'PRINCEWARE', 80, '500ML', 'https://rukminim1.flixcart.com/image/280/280/kex5ci80/bottle/g/g/d/500-pearl-infuser-bottle-808349268187-princeware-original-imafvhyzvxrvjfdm.jpeg?q=70'),
(7, 'MASON JARS', 90, 'PACK', 'https://rukminim1.flixcart.com/image/280/280/k7w8eq80/container/a/h/n/pp-353-green-lid-mastercook-original-imafqfbwgczatgmh.jpeg?q=70'),
(8, 'PRINCEWARE', 225, 'PACK', 'https://rukminim1.flixcart.com/image/280/280/k69ncsw0/oil-dispenser/k/k/r/dispenser-oil-pot-stainless-steel-500ml-princeware-original-imafzrhg8nyyhbnb.jpeg?q=70');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `description` varchar(30) NOT NULL,
  `cast` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `comName` varchar(30) NOT NULL,
  `img` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `snacks`
--

CREATE TABLE `snacks` (
  `prid` int(11) NOT NULL,
  `desc` varchar(100) NOT NULL,
  `qty` varchar(20) NOT NULL,
  `rate` int(11) NOT NULL,
  `url` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `snacks`
--

INSERT INTO `snacks` (`prid`, `desc`, `qty`, `rate`, `url`) VALUES
(1, 'BRITANNIA Bourban Biscuits cream', '4 * 100 g', 87, 'https://rukminim1.flixcart.com/image/280/280/krtjgcw0/cookie-biscuit/e/e/d/bourbon-sandwich-biscuits-britannia-original-imag5j4u3dggthky.jpeg?q=70'),
(2, 'Britania Little Hearts Classic Sweet', '75 g', 19, 'https://rukminim1.flixcart.com/image/280/280/kpmy8i80/cookie-biscuit/t/o/p/little-hearts-britannia-original-imag3tkcy5wt7pek.jpeg?q=70'),
(3, 'OREO Choco Biscuits Cream Sandwich', '46.3 g', 8, 'https://rukminim1.flixcart.com/image/280/280/kekadu80/cookie-biscuit/s/w/j/46-3-choco-creme-biscuits-oreo-original-imafv863ywj8hxzg.jpeg?q=70'),
(4, 'Sunfeast Mom Magic', '200 g', 30, 'https://rukminim1.flixcart.com/image/280/280/l071d3k0/cookie-biscuit/6/z/3/-original-imagcf89phmpcenn.jpeg?q=70'),
(5, 'PARLE Waafare piri piri', '100 g', 22, 'https://rukminim1.flixcart.com/image/280/280/ky1vl3k0/chips/v/f/o/-original-imagadczemt2gksk.jpeg?q=70'),
(6, 'Lays Magic Masala Packts', '3 x 115g', 103, 'https://rukminim1.flixcart.com/image/280/280/ksdjma80/chips/q/c/8/345-potato-chips-lay-s-original-imag5yggu7dqg3tg.jpeg?q=70'),
(7, 'Pepsi Black Can', '250ml', 22, 'https://rukminim1.flixcart.com/image/280/280/jhuvjww0/aerated-drink/g/g/z/250-black-pepsi-original-imaf5rzm5tz8gybf.jpeg?q=70'),
(8, 'RED BULL ', '600ml', 31, 'https://rukminim1.flixcart.com/image/280/280/kzrbiq80/energy-sport-drink-mix/i/m/f/250-watermelon-1-red-bull-original-imagbp6zdwbmwxq8.jpeg?q=70');

-- --------------------------------------------------------

--
-- Table structure for table `staples`
--

CREATE TABLE `staples` (
  `prid` int(11) NOT NULL,
  `desc` varchar(100) NOT NULL,
  `rate` int(11) NOT NULL,
  `qty` varchar(11) NOT NULL,
  `url` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `staples`
--

INSERT INTO `staples` (`prid`, `desc`, `rate`, `qty`, `url`) VALUES
(1, 'Dabur Cold Pressed Mustard Oil Plastic Bottle', 310, '1L', 'https://rukminim1.flixcart.com/image/280/280/kk4c13k0/edible-oil/6/j/v/cold-pressed-plastic-bottle-mustard-oil-dabur-original-imafzjfcnrmxxs75.jpeg?q=70'),
(2, 'Oleev Smart Blended Oil Can Plastic Tank', 993, '5L', 'https://rukminim1.flixcart.com/image/280/280/kq8dua80/edible-oil/3/a/j/smart-can-blended-oil-oleev-original-imag4aeegrytnwsu.jpeg?q=70'),
(3, 'GOld Winner Refined Sunflower Oil Pouch', 179, '1L', 'https://rukminim1.flixcart.com/image/280/280/kwv0djk0/edible-oil/q/5/1/-original-imag9fsfhzfe43w3.jpeg?q=70'),
(4, 'Godrej jersey Ghee 100ml Pouch Bottole ', 46, '100mL', 'https://rukminim1.flixcart.com/image/280/280/ksaoqkw0/ghee/p/j/q/na-pouch-godrej-jersey-original-imag5w33yre3hjht.jpeg?q=70'),
(5, 'FortuneSunlite Refined Sunflower Oil Pouch', 185, '1L', 'https://rukminim1.flixcart.com/image/280/280/k7usyvk0/edible-oil/e/t/c/1-sunlite-refined-pouch-sunflower-oil-fortune-original-imafpzwhyyhhvzbk.jpeg?q=70'),
(6, 'FortuneSunlite Refined Sunflower Oil Can', 929, '5L', 'https://rukminim1.flixcart.com/image/280/280/k7usyvk0/edible-oil/f/y/f/5-sunlite-refined-can-sunflower-oil-fortune-original-imafpzwh27hmzacq.jpeg?q=70'),
(7, 'Super Sarvottam Physically refined Rice', 178, '1L', 'https://rukminim1.flixcart.com/image/280/280/kfwvcsw0/edible-oil/5/y/v/1-rice-bran-oil-pouch-rice-bran-oil-super-sarvottam-original-imafw9mghfrbkqff.jpeg?q=70'),
(8, ' ORGANIC Unrefined mustard oil', 399, '1L', 'https://rukminim1.flixcart.com/image/280/280/kjvrdzk0/edible-oil/d/5/s/na-plastic-bottle-mustard-oil-24-mantra-organic-original-imafzce3grkezhvm.jpeg?q=70'),
(9, 'Sunland Refined Sunflower Oil pouch', 175, '1L', 'https://rukminim1.flixcart.com/image/280/280/jlqwpe80/edible-oil/b/7/m/1-refined-pouch-sunflower-oil-sunland-original-imaf8swskbyrgk5x.jpeg?q=70'),
(10, 'Ruchi gold Palm Oil Pouch', 167, '1L', 'https://rukminim1.flixcart.com/image/280/280/l05lx8w0/edible-oil/l/v/e/-original-imagcy268pngbkvv.jpeg?q=70'),
(11, 'Fortune Rice Bran Oil Pouch', 212, '1L', 'https://rukminim1.flixcart.com/image/280/280/kqidx8w0/edible-oil/b/8/j/na-pouch-rice-bran-oil-fortune-original-imag4gb35zffhkaj.jpeg?q=70'),
(12, 'oleev Health Blended Oil Can', 1040, '5L', 'https://rukminim1.flixcart.com/image/280/280/kq8dua80/edible-oil/c/9/l/health-can-blended-oil-oleev-original-imag4aeey7fnauxh.jpeg?q=70'),
(13, 'GRB  Cow Ghee 500ml Pouch ', 319, '500mL', 'https://rukminim1.flixcart.com/image/280/280/j6mhxu80/ghee/y/j/x/500-na-pouch-grb-original-imaex2ffmjnhkmzw.jpeg?q=70'),
(14, 'Nestle Everday Shashi Ghee 1L ', 418, '1L', 'https://rukminim1.flixcart.com/image/280/280/kcc9q4w0/ghee/y/7/u/1-everyday-shahi-ghee-tetrapack-nestle-original-imafthxzksctaxhm.jpeg?q=70'),
(15, 'Saffola Active Blended Oil can', 953, '5L', 'https://rukminim1.flixcart.com/image/280/280/ky3b0y80/edible-oil/w/g/w/-original-imagaefdxhy8dufj.jpeg?q=70'),
(16, 'Sundrop Superlite Advanced Sunflower Oil', 554, '3L', 'https://rukminim1.flixcart.com/image/280/280/k1s6ljk0/edible-oil/p/t/r/3-superlite-advanced-can-sunflower-oil-sundrop-original-imafh4gjzf6bhyef.jpeg?q=70'),
(17, 'Premium Cow Ghee 1L Tetrapack by Raymart', 434, '1L', 'https://rukminim1.flixcart.com/image/280/280/kg2l47k0/ghee/s/g/f/1-premium-cow-ghee-carton-flipkart-supermart-original-imafwe8vcpytyseu.jpeg?q=70'),
(18, 'Nutralite Doodhshakti Pure ghee 1L carton', 411, '1L', 'https://rukminim1.flixcart.com/image/280/280/klicfww0/ghee/n/o/q/1-doodhshakti-pure-ghee-carton-nutralite-original-imagym9gwjgqntnc.jpeg?q=70'),
(19, 'Lion Dates qyno packs', 158, '500g', 'https://rukminim1.flixcart.com/image/280/280/knni7ww0/nut-dry-fruit/z/l/g/500-qyno-seeded-dates-buy-1-get-1-free-pouch-lion-original-imag2aywghrzn7wf.jpeg?q=70'),
(20, 'Manna Black Dates', 260, '400g', 'https://rukminim1.flixcart.com/image/280/280/kzegk280/nut-dry-fruit/1/i/a/-original-imagbf9ygvwpfmhv.jpeg?q=70'),
(21, 'Tata Filter instant Coffee', 49, '50g', 'https://rukminim1.flixcart.com/image/280/280/kwv0djk0/coffee/6/a/s/-original-imag9fs83ygdzcns.jpeg?q=70'),
(22, 'Nescafe red Travel Kit Instant coffee', 630, '200 g', 'https://rukminim1.flixcart.com/image/280/280/k9k8wi80/coffee/x/c/y/200-red-travel-kit-instant-coffee-carton-nescafe-original-imafrbtc8s2vzwwg.jpeg?q=70'),
(23, 'AAC Pure coconut Oil pouch purely natural', 267, '1L', 'https://rukminim1.flixcart.com/image/280/280/jj7givk0/edible-oil/f/4/e/1-na-pouch-coconut-oil-aac-original-imaf6u7c3px4fmdk.jpeg?q=70'),
(24, 'Akashayakalpa Desi Cow Ghee 300ml', 524, '300ml', 'https://rukminim1.flixcart.com/image/280/280/kzrbiq80/ghee/q/2/n/-original-imagbzx8tb2akccb.jpeg?q=70');

-- --------------------------------------------------------

--
-- Table structure for table `userdetails`
--

CREATE TABLE `userdetails` (
  `user_Id` varchar(20) NOT NULL,
  `name` varchar(30) NOT NULL,
  `mail` varchar(30) NOT NULL,
  `password` varchar(20) NOT NULL,
  `phone` varchar(12) NOT NULL,
  `address` varchar(40) NOT NULL,
  `pic` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `userdetails`
--

INSERT INTO `userdetails` (`user_Id`, `name`, `mail`, `password`, `phone`, `address`, `pic`) VALUES
('12345', 'hfdksfysd dsfadf', 'hariharansekar11@gmail.com', '12345', '8428978917', 'erwfdd', 'Screenshot (7).png'),
('hari@raymart', 'HARIHARAN S', 'hariharansekar11@gmail.com', 'karan003', '8428978917', 'N0:104', '485=O.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `babycare`
--
ALTER TABLE `babycare`
  ADD PRIMARY KEY (`prid`);

--
-- Indexes for table `food`
--
ALTER TABLE `food`
  ADD PRIMARY KEY (`prid`);

--
-- Indexes for table `house`
--
ALTER TABLE `house`
  ADD PRIMARY KEY (`prid`);

--
-- Indexes for table `kitchen`
--
ALTER TABLE `kitchen`
  ADD PRIMARY KEY (`prid`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `snacks`
--
ALTER TABLE `snacks`
  ADD PRIMARY KEY (`prid`);

--
-- Indexes for table `staples`
--
ALTER TABLE `staples`
  ADD PRIMARY KEY (`prid`);

--
-- Indexes for table `userdetails`
--
ALTER TABLE `userdetails`
  ADD PRIMARY KEY (`user_Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `babycare`
--
ALTER TABLE `babycare`
  MODIFY `prid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `food`
--
ALTER TABLE `food`
  MODIFY `prid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `house`
--
ALTER TABLE `house`
  MODIFY `prid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `kitchen`
--
ALTER TABLE `kitchen`
  MODIFY `prid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `snacks`
--
ALTER TABLE `snacks`
  MODIFY `prid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `staples`
--
ALTER TABLE `staples`
  MODIFY `prid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
