package Entity;

import javax.persistence.*;

@Entity
@Table(name="product")
public class product 
{
	@Id	
	private int id;
	
	@Column(name="name")
	private String name;
	
	@Column(name="description")
	private String description;
	
	@Column(name="cast")
	private int cast;
	
	@Column(name="qty")
	private int qty;
	
	@Column(name="comName")
	private String comName;
	
	@Column(name="img")
	private String img;
	
	
	public String toString()
	{
		
		return "\n Id" + getId()+"\n name" + getName() + " \n Des" +getDescription() + "\n image" + getImg();
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public int getCast() {
		return cast;
	}


	public void setCast(int cast) {
		this.cast = cast;
	}


	public int getQty() {
		return qty;
	}


	public void setQty(int qty) {
		this.qty = qty;
	}


	public String getComName() {
		return comName;
	}


	public void setComName(String comName) {
		this.comName = comName;
	}


	public String getImg() {
		return img;
	}


	public void setImg(String img) {
		this.img = img;
	}
	
	
	
	

}
