package servelt;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.cfg.Configuration;

/**
 * Servlet implementation class cart
 */
public class cart extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void service(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		RequestDispatcher rs;
		System.out.println("server");
		Configuration cfg = new Configuration();
		Session S = cfg.configure("connect.cfg.xml").buildSessionFactory().openSession();
		System.out.println(request.getParameter("prid"));
		System.out.println(request.getParameter("desc"));
		System.out.println(request.getParameter("url"));
		System.out.println(request.getParameter("qty"));
		System.out.println(request.getParameter("rate"));
	
		

		rs = request.getServletContext().getRequestDispatcher("/index.jsp");	
		
		
		rs.forward(request, response);
	  	
		S.close();
	}
}
