package servelt;


import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.hibernate.Session;
import org.hibernate.cfg.Configuration;

import Entity.userdetails;

@MultipartConfig(
		location="D:\\FullStackSoftware\\JAVA\\example1\\Groceryup\\src\\main\\webapp\\images\\users",
		fileSizeThreshold = 1024 * 1024 ,// 1mb
		maxFileSize=1024 * 1024 * 10 ,//10mb
		maxRequestSize = 1024 * 1024 * 11 // 11 mb
		)
public class signup extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	
	
   
	protected void service(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		// TODO Auto-generated method stub
		RequestDispatcher rs;
		
		Configuration cfg = new Configuration();
		Session S = cfg.configure("connect.cfg.xml").buildSessionFactory().openSession();
		
		S.getTransaction().begin();
		
		
		String name = request.getParameter("firstname")+" "+request.getParameter("lastname");
		String user_Id = request.getParameter("user_Id");
		String mail    = request.getParameter("mail");
		String pwd    = request.getParameter("password1");
		String phone = request.getParameter("phone");
		String add= request.getParameter("add");
		String  pic=null ;
		String meg=null;
		/********************  UPLOADING A IMAGES      ******************************************/
		
		try {
			Part part = request.getPart("pic");  // 
			part.write(filename(part));
			
			meg = "file upload succes";
			pic= filename(part);
			System.out.println(meg);
		}
		catch(Exception e)
		{
			meg = "file upload failure" + e.getMessage();
			System.out.println(meg);
		}
		userdetails u = new userdetails();
		u.setUser_Id(user_Id);
		u.setName(name);
		u.setMail(mail);
		u.setPhone(phone);
		u.setPassword(pwd);
		u.setAddress(add);
		u.setPic(pic);
		
		S.save(u);
		
		S.getTransaction().commit();
		
		S.close();
		
		//System.out.println("Adding Sucessfully");
		
		request.getRequestDispatcher("/index.jsp").forward(request, response);
	

		
	}
 private String filename(Part part) {
	 String disposition=part.getHeader("content-disposition");
	 if(!disposition.contains("filename=")) {
		 return null;
	 }
	 int beginIndex = disposition.indexOf("filename=") + 10;
	 int lastIndex = disposition.length()-1;
	 
	 return disposition.substring(beginIndex, lastIndex);
	 
 }

}
